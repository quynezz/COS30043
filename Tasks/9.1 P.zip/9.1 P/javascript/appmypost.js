const app = Vue.createApp({});

app.component("app-mypost", {
  data: function () {
    return {
      statPosts: [],
      strStatus: "",
      selectedIndex: -1,
    };
  },
  template: `
    <div class="container text-center">
      <h1 class="my-4">Status Post App</h1>
      <div class="mb-3">
        <b>Status:</b>&nbsp;
        <div class="d-inline-block" style="width: auto;">
          <input v-model="strStatus" class="form-control d-inline-block w-100" />
        </div>
        &nbsp;
        <button v-on:click="add(strStatus)" class="btn btn-success">Post</button>
      </div>
      <div v-for="(status, index) in statPosts" :key="index"
           :class="{ selected: selectedIndex === index }"
           @click="select(index)" class="p-2 my-2 border rounded text-left" style="max-width: 500px; margin: 0 auto;">
        <span>{{ status }}</span>
        <button v-on:click="remove(index)" class="btn btn-danger btn-sm float-right">Delete</button>
      </div>
    </div>
  `,
  methods: {
    add: function (status) {
      if (status.trim()) {
        this.statPosts.push(status);
        this.strStatus = "";
        this.selectedIndex = -1;
      }
    },
    remove: function (index) {
      this.statPosts.splice(index, 1);
      if (this.selectedIndex === index) {
        this.selectedIndex = -1;
      }
    },
    select: function (index) {
      this.selectedIndex = index;
    },
  },
});

app.mount("#app");
