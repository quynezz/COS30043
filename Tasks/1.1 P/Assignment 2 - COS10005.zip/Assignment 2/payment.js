function makePayment() {
    // Get form elements
    var fullName = document.querySelector('input[name="full-name"]').value;
    var email = document.querySelector('input[name="email"]').value;
    var address = document.querySelector('input[name="address"]').value;
    var deliveryMethod = document.querySelector('input[name="delivery"]:checked');
    var city = document.querySelector('select[name="city"]').value;
    var zipCode = document.querySelector('input[name="zip-code"]').value;
    var cardNumber = document.querySelector('input[name="card-number"]').value;
    var expMonth = document.querySelector('input[name="exp-month"]').value;
    var expYear = document.querySelector('select[name="exp-year"]').value;
    var cvv = document.querySelector('input[name="cvv"]').value;

    // Check if any input is empty
    if (!fullName || !email || !address || !deliveryMethod || !city || !zipCode || !cardNumber || !expMonth || !expYear || !cvv) {
        alert("You haven't filled the form. Please complete all fields.");
    } else {
        // Proceed with payment logic (you can replace this with your actual payment processing)

        // Display success message
        alert("Payment successful! Thanks for shopping!");
    }
}
